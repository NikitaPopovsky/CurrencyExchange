package org.currency_exchange;

import org.currency_exchange.exception.CodeIsMissing;

public final class ValidationUtil {
    public static validationCode(String code) {
        if (code.isEmpty()) {
            throw new CodeIsMissing("Не указан код валюты");
        }
        if (code.length() != 3) {

        }
    }
}

package org.currency_exchange.filters;

import jakarta.servlet;
import org.currency_exchange.exception.CurrencyExchangeException;

public class HandleExceptionFilter implements Filter {
    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        try {
            filterChain.doFilter(servletRequest, servletResponse);
        } catch (CurrencyExchangeException e) {
            handleException(e, servletResponse);
        }
    }

    private void handleException(CurrencyExchangeException exception, ServletResponse resp) {
        resp.setStatus(exception.getStatusCode());
        JSONMapper.writeValue(resp.getWriter(),exception.getMessage());
    }
}
